# Deployment Checklist - Consumet API v2

## Pre-Deployment

- [ ] Update `.env` with production values
  - [ ] Set `NODE_ENV=production`
  - [ ] Set `LOG_LEVEL=info`
  - [ ] Configure Redis connection
  - [ ] Update `PORT` if needed

- [ ] Run tests
  - [ ] `npm run build` (successful)
  - [ ] Test endpoints locally
  - [ ] Verify `/health` endpoint
  - [ ] Test search functionality
  - [ ] Test watch endpoint with multiple servers

- [ ] Security review
  - [ ] No hardcoded secrets in code
  - [ ] `.env` file not committed
  - [ ] CORS origin configured properly
  - [ ] Rate limiting considered

- [ ] Performance check
  - [ ] Response times acceptable (<5s)
  - [ ] Memory usage reasonable (<500MB)
  - [ ] Database connections stable
  - [ ] Redis working if configured

## Docker Deployment

```bash
# Build image
docker build -t consumet-api:2.0.0 .

# Run container
docker run -d \
  --name consumet \
  -e PORT=3000 \
  -e NODE_ENV=production \
  -e REDIS_HOST=redis \
  -p 3000:3000 \
  consumet-api:2.0.0

# Verify running
docker logs consumet
curl http://localhost:3000/health
```

Deployment checklist:
- [ ] Dockerfile exists and builds
- [ ] Docker image runs without errors
- [ ] Port mapping correct
- [ ] Environment variables passed
- [ ] Health check passes
- [ ] Logs visible

## Vercel Deployment

```bash
# Install Vercel CLI
npm install -g vercel

# Deploy
vercel deploy --prod

# Or: Connect GitHub and auto-deploy
```

Deployment checklist:
- [ ] GitHub repo connected
- [ ] Environment variables set in Vercel UI
  - [ ] NODE_ENV=production
  - [ ] REDIS_URL (if using)
- [ ] Build completes without errors
- [ ] Deployment completes
- [ ] Health endpoint responds
- [ ] CORS headers correct

## Railway Deployment

```bash
# Install Railway CLI
npm install -g @railway/cli

# Login
railway login

# Deploy
railway up
```

Deployment checklist:
- [ ] Railway project created
- [ ] Environment variables configured
- [ ] Build passes
- [ ] Server starts successfully
- [ ] Health check working

## Manual/VPS Deployment

```bash
# Clone repository
git clone https://github.com/user/api.consumet.org.git
cd api.consumet.org

# Install dependencies
npm ci --only=production

# Build
npm run build

# Create .env file
cp .env.example .env
# Edit .env with production values

# Start with PM2
npm install -g pm2
pm2 start dist/main.js --name consumet

# Save PM2 config
pm2 save
pm2 startup
```

Deployment checklist:
- [ ] Node.js 18+ installed
- [ ] Dependencies installed
- [ ] Build successful
- [ ] .env configured
- [ ] PM2 running
- [ ] Systemd service created
- [ ] Nginx reverse proxy configured
- [ ] SSL certificate installed
- [ ] Firewall rules updated

## Health Checks

After deployment, verify:

```bash
# 1. Server running
curl http://your-domain/health

# 2. Readiness check
curl http://your-domain/health/ready

# 3. Search working
curl "http://your-domain/movies/test"

# 4. Check logs
# Docker: docker logs consumet
# PM2: pm2 logs consumet
# Vercel: vercel logs

# 5. Monitor performance
# Check response times
# Check memory usage
# Check error rates
```

All should return 200 status.

## Monitoring Setup

### Metrics to Monitor
- [ ] Response times (aim for <2s)
- [ ] Error rates (aim for <1%)
- [ ] CPU usage (aim for <50%)
- [ ] Memory usage (aim for <500MB)
- [ ] Database connections
- [ ] Cache hit ratio

### Recommended Tools
- **Status Page**: https://www.statuspage.io
- **Uptime Monitoring**: https://www.uptime.com
- **Log Aggregation**: https://www.loggly.com
- **Performance**: https://sentry.io

### Health Check URLs
- `/health` - Server status
- `/health/ready` - Kubernetes readiness
- Monitor every 30 seconds

## Logging & Debugging

```bash
# View logs with timestamps
# Docker
docker logs -f consumet --since 1h

# PM2
pm2 logs consumet

# Vercel
vercel logs
```

Check for:
- [ ] No ERROR level logs
- [ ] No WARN level logs (unless expected)
- [ ] Server started successfully
- [ ] Connections established
- [ ] No timeout errors

## Rollback Plan

If issues occur:

1. **Quick Rollback (Docker)**
   ```bash
   docker run -d --name consumet-old \
     -p 3001:3000 \
     consumet-api:1.0.0
   ```

2. **Vercel Rollback**
   - Go to Vercel dashboard
   - Select previous deployment
   - Click "Promote to Production"

3. **Manual Rollback**
   ```bash
   git checkout previous-tag
   npm run build
   pm2 restart consumet
   ```

## Post-Deployment

- [ ] Notify users of new version
- [ ] Monitor for issues first 24 hours
- [ ] Check error logs regularly
- [ ] Verify all endpoints working
- [ ] Test with real users if possible
- [ ] Update status page if applicable

## Database Considerations

If using Supabase:
- [ ] Connection string configured
- [ ] Migrations applied
- [ ] RLS policies verified
- [ ] Backup configured

## Performance Tuning

If slow:
- [ ] Enable Redis caching
  ```env
  REDIS_HOST=your-redis-host
  REDIS_PORT=6379
  ```

- [ ] Increase cache TTL
  ```env
  CACHE_TTL=7200
  ```

- [ ] Add CDN for static files
- [ ] Use compression middleware
- [ ] Monitor slow queries

## Security Hardening

- [ ] Update dependencies
  ```bash
  npm audit fix
  ```

- [ ] Enable HTTPS only
- [ ] Set security headers
- [ ] Configure CORS properly
- [ ] Add rate limiting if needed
- [ ] Review .env variables

## Maintenance Schedule

- **Daily**: Check health endpoint
- **Weekly**: Review error logs
- **Monthly**: Update dependencies
- **Quarterly**: Security audit
- **Yearly**: Full system review

## Success Criteria

Production deployment is successful when:

✅ Server running and healthy
✅ All endpoints responding
✅ Response times <2s
✅ Error rate <1%
✅ Memory stable
✅ Logs clean
✅ Health checks passing
✅ Users reporting no issues
✅ Monitoring alerts working

---

For help:
1. Check logs: `npm start` in dev mode
2. Review README.md
3. Check QUICK_START.md
4. Review API_EXAMPLES.md
