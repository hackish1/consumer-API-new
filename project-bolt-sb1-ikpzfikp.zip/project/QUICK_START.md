# Quick Start Guide - Consumet API v2

## Installation

```bash
# Clone and install
git clone https://github.com/hackish1/api.consumet.org.git
cd api.consumet.org
npm install

# Copy environment config
cp .env.example .env

# Build
npm run build

# Start
npm start
```

Server runs on `http://localhost:3000`

---

## Multi-Server Streaming Example

The key feature: **automatic fallback between servers**

### Search Movies
```bash
curl "http://localhost:3000/movies/The%20Matrix"
```

### Get Movie Details
```bash
curl "http://localhost:3000/movies/info?id=movie-123"
```

### Get Streaming Sources (Auto-Fallback)
```bash
curl "http://localhost:3000/movies/watch?episodeId=episode-123&mediaId=movie-456&servers=vidcloud,midstream,filecdn"
```

**What happens:**
1. Tries VidCloud first
2. If no sources, tries MidStream
3. If that fails, tries FileCDN
4. Returns all sources found from working servers

Response:
```json
{
  "sources": [
    {
      "url": "https://vidcloud.co/stream/...",
      "quality": "1080p",
      "server": "vidcloud"
    },
    {
      "url": "https://midstream.io/stream/...",
      "quality": "720p",
      "server": "midstream"
    }
  ],
  "availableServers": ["vidcloud", "midstream", "filecdn", "streamhub", "mixdrop", "upcloud"]
}
```

---

## Development

### Hot Reload
```bash
npm run dev
```

### View Logs
```bash
NODE_ENV=development LOG_LEVEL=debug npm run dev
```

---

## Configuration

Edit `.env`:

```env
# Server
PORT=3000
NODE_ENV=development

# Caching (optional)
REDIS_HOST=localhost
REDIS_PORT=6379
```

---

## Available Servers

The API automatically tries servers in this priority:

1. **VidCloud** - Most reliable
2. **MidStream** - Good fallback
3. **FileCDN** - Alternative
4. **StreamHub**
5. **MixDrop**
6. **UpCloud**

You can override the priority:
```bash
# Custom order
curl "...&servers=filecdn,midstream,vidcloud"
```

---

## Health Checks

```bash
# Server health
curl http://localhost:3000/health

# Ready check (for Kubernetes)
curl http://localhost:3000/health/ready
```

---

## Troubleshooting

### Movie won't play
1. Check the server is working: `curl http://localhost:3000/movies/trending`
2. Try a different server in the query: `&servers=midstream,filecdn`
3. Check logs: `LOG_LEVEL=debug npm run dev`

### Slow responses
Enable Redis caching in `.env`:
```env
REDIS_HOST=localhost
REDIS_PORT=6379
```

Then restart the server.

---

## What's Different from v1?

| Feature | v1 | v2 |
|---------|----|----|
| Node version | 12+ | 18+ |
| Module system | CommonJS | ES Modules |
| Logging | console.log | Pino |
| Validation | Manual | Zod schemas |
| Server fallback | Manual | Automatic |
| Error handling | Per route | Centralized |
| TypeScript | Basic | Strict |

---

## Next Steps

1. Deploy to production (Docker, Vercel, Render, Railway)
2. Set up Redis for caching
3. Monitor with health checks
4. Check [MODERNIZATION.md](./MODERNIZATION.md) for architecture details

---

For full documentation: [MODERNIZATION.md](./MODERNIZATION.md)
