import Redis from 'ioredis';
import { logger } from './logger.js';

export class CacheManager {
  private redis: Redis | null;
  private readonly defaultTTL: number;

  constructor(redis?: Redis, ttl: number = 3600) {
    this.redis = redis || null;
    this.defaultTTL = ttl;
  }

  async get<T>(key: string): Promise<T | null> {
    if (!this.redis) return null;

    try {
      const cached = await this.redis.get(key);
      if (cached) {
        logger.debug(`Cache hit for key: ${key}`);
        return JSON.parse(cached) as T;
      }
      return null;
    } catch (error) {
      logger.error(`Cache retrieval error for key ${key}:`, error);
      return null;
    }
  }

  async set<T>(key: string, value: T, ttl?: number): Promise<void> {
    if (!this.redis) return;

    try {
      const serialized = JSON.stringify(value);
      const ttlSeconds = ttl || this.defaultTTL;
      await this.redis.setex(key, ttlSeconds, serialized);
      logger.debug(`Cache set for key: ${key} (TTL: ${ttlSeconds}s)`);
    } catch (error) {
      logger.error(`Cache write error for key ${key}:`, error);
    }
  }

  async delete(key: string): Promise<void> {
    if (!this.redis) return;

    try {
      await this.redis.del(key);
      logger.debug(`Cache deleted for key: ${key}`);
    } catch (error) {
      logger.error(`Cache deletion error for key ${key}:`, error);
    }
  }

  async fetch<T>(key: string, fetcher: () => Promise<T>, ttl?: number): Promise<T> {
    const cached = await this.get<T>(key);
    if (cached) return cached;

    const result = await fetcher();
    await this.set(key, result, ttl);
    return result;
  }

  isEnabled(): boolean {
    return this.redis !== null;
  }
}

export default CacheManager;
