import { z } from 'zod';
import { AVAILABLE_SERVERS } from '../core/types.js';

export const EpisodeQuerySchema = z.object({
  episodeId: z.string().min(1, 'episodeId is required'),
  mediaId: z.string().min(1, 'mediaId is required'),
  server: z.enum(Object.keys(AVAILABLE_SERVERS) as [string, ...string[]]).optional(),
  servers: z
    .union([z.string(), z.array(z.string())])
    .transform((val) => (typeof val === 'string' ? val.split(',') : val))
    .refine(
      (servers) =>
        servers.every((s) => Object.keys(AVAILABLE_SERVERS).includes(s)),
      'Invalid server name',
    )
    .optional(),
});

export const SearchQuerySchema = z.object({
  query: z.string().min(1, 'query is required'),
  page: z.coerce.number().int().positive().optional(),
});

export const MediaInfoQuerySchema = z.object({
  id: z.string().min(1, 'id is required'),
});

export type EpisodeQuery = z.infer<typeof EpisodeQuerySchema>;
export type SearchQuery = z.infer<typeof SearchQuerySchema>;
export type MediaInfoQuery = z.infer<typeof MediaInfoQuerySchema>;
