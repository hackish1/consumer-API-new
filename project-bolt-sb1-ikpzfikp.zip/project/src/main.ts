import 'dotenv/config';
import Fastify from 'fastify';
import fastifyCors from '@fastify/cors';
import Redis from 'ioredis';

import { logger } from './utils/logger.js';
import { CacheManager } from './utils/cache-manager.js';
import moviesRouter from './routes/movies.js';
import animeRouter from './routes/anime.js';
import healthRouter from './routes/health.js';

const PORT = Number(process.env.PORT) || 3000;
const NODE_ENV = process.env.NODE_ENV || 'development';
const CACHE_TTL = Number(process.env.CACHE_TTL) || 3600;

let redis: Redis | null = null;
let cache: CacheManager;

async function initializeRedis(): Promise<Redis | null> {
  if (!process.env.REDIS_HOST) {
    logger.warn('Redis not configured, running without cache');
    return null;
  }

  try {
    const client = new Redis({
      host: process.env.REDIS_HOST,
      port: Number(process.env.REDIS_PORT) || 6379,
      password: process.env.REDIS_PASSWORD,
      retryStrategy: (times) => Math.min(times * 50, 2000),
      maxRetriesPerRequest: null,
    });

    client.on('error', (err) => {
      logger.error('Redis connection error:', err);
    });

    client.on('connect', () => {
      logger.info('Redis connected successfully');
    });

    return client;
  } catch (error) {
    logger.error('Failed to initialize Redis:', error);
    return null;
  }
}

async function startServer() {
  try {
    redis = await initializeRedis();
    cache = new CacheManager(redis || undefined, CACHE_TTL);

    const fastify = Fastify({
      maxParamLength: 1000,
    });

    await fastify.register(fastifyCors, {
      origin: '*',
      methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    });

    fastify.decorate('cache', cache);

    await fastify.register(healthRouter, { prefix: '/health' });
    await fastify.register(moviesRouter, { prefix: '/movies' });
    await fastify.register(animeRouter, { prefix: '/anime' });

    fastify.get('/', async (_, reply) => {
      return reply.send({
        message: 'Welcome to Consumet API v2',
        version: '2.0.0',
        environment: NODE_ENV,
        cacheEnabled: cache.isEnabled(),
      });
    });

    fastify.get('*', async (_, reply) => {
      return reply.status(404).send({
        error: 'Not Found',
        message: 'The requested endpoint does not exist',
      });
    });

    await fastify.listen({ port: PORT, host: '0.0.0.0' });
    logger.info(`Server listening on port ${PORT} in ${NODE_ENV} mode`);
  } catch (error) {
    logger.error('Failed to start server:', error);
    process.exit(1);
  }
}

process.on('SIGTERM', async () => {
  logger.info('SIGTERM received, shutting down gracefully');
  if (redis) {
    await redis.quit();
  }
  process.exit(0);
});

process.on('SIGINT', async () => {
  logger.info('SIGINT received, shutting down gracefully');
  if (redis) {
    await redis.quit();
  }
  process.exit(0);
});

startServer();
