import { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';

async function healthRoutes(fastify: FastifyInstance) {
  fastify.get('/', async (_request: FastifyRequest, reply: FastifyReply) => {
    return reply.status(200).send({
      status: 'healthy',
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
    });
  });

  fastify.get('/ready', async (_request: FastifyRequest, reply: FastifyReply) => {
    return reply.status(200).send({
      ready: true,
      timestamp: new Date().toISOString(),
    });
  });
}

export default healthRoutes;
