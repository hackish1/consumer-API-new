import { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import { ANIME } from '@consumet/extensions';
import { logger } from '../utils/logger.js';

async function animeRoutes(fastify: FastifyInstance) {
  const provider = new (ANIME as any).Hianime();
  const cache = (fastify as any).cache;

  fastify.get('/', async (_request: FastifyRequest, reply: FastifyReply) => {
    return reply.status(200).send({
      message: 'Gogoanime Anime Provider',
      endpoints: [
        'GET /:query - Search anime',
        'GET /info?id=:id - Get anime info',
        'GET /watch?episodeId=:id - Get episode sources',
        'GET /trending - Get trending anime',
        'GET /recent - Get recent anime',
      ],
    });
  });

  fastify.get('/:query', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const { query } = request.params as { query: string };
      const page = (request.query as any).page || 1;
      const cacheKey = `anime:search:${query}:${page}`;

      const results = await cache.fetch(cacheKey, () =>
        provider.search(decodeURIComponent(query), page),
      );

      return reply.status(200).send(results);
    } catch (error) {
      logger.error('Anime search error:', error);
      return reply.status(500).send({
        error: 'Search failed',
        message: (error as Error).message,
      });
    }
  });

  fastify.get('/info', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const { id } = request.query as any;

      if (!id) {
        return reply.status(400).send({
          error: 'Missing parameter',
          message: 'id is required',
        });
      }

      const cacheKey = `anime:info:${id}`;
      const info = await cache.fetch(cacheKey, () => provider.fetchAnimeInfo(id));

      return reply.status(200).send(info);
    } catch (error) {
      logger.error('Anime info error:', error);
      return reply.status(500).send({
        error: 'Failed to fetch anime info',
        message: (error as Error).message,
      });
    }
  });

  fastify.get('/watch', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const { episodeId } = request.query as any;

      if (!episodeId) {
        return reply.status(400).send({
          error: 'Missing parameter',
          message: 'episodeId is required',
        });
      }

      const cacheKey = `anime:watch:${episodeId}`;
      const sources = await cache.fetch(cacheKey, () =>
        provider.fetchEpisodeSources(episodeId),
      );

      return reply.status(200).send(sources);
    } catch (error) {
      logger.error('Anime watch error:', error);
      return reply.status(500).send({
        error: 'Failed to fetch sources',
        message: (error as Error).message,
      });
    }
  });

  fastify.get('/trending', async (_request: FastifyRequest, reply: FastifyReply) => {
    try {
      const cacheKey = 'anime:trending';
      const results = await cache.fetch(cacheKey, () => provider.fetchTrendingAnime?.());

      return reply.status(200).send(results);
    } catch (error) {
      logger.error('Anime trending error:', error);
      return reply.status(500).send({
        error: 'Failed to fetch trending anime',
        message: (error as Error).message,
      });
    }
  });

  fastify.get('/recent', async (_request: FastifyRequest, reply: FastifyReply) => {
    try {
      const cacheKey = 'anime:recent';
      const results = await cache.fetch(cacheKey, () => provider.fetchRecentEpisodes?.());

      return reply.status(200).send(results);
    } catch (error) {
      logger.error('Anime recent error:', error);
      return reply.status(500).send({
        error: 'Failed to fetch recent anime',
        message: (error as Error).message,
      });
    }
  });
}

export default animeRoutes;
