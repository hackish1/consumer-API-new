import { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import { MOVIES } from '@consumet/extensions';
import { StreamManager } from '../core/stream-manager.js';
import { CacheManager } from '../utils/cache-manager.js';
import { EpisodeQuerySchema, SearchQuerySchema, MediaInfoQuerySchema } from '../utils/validation.js';
import { logger } from '../utils/logger.js';
import { ZodError } from 'zod';

async function moviesRoutes(fastify: FastifyInstance) {
  const provider = new MOVIES.FlixHQ();
  const streamManager = new StreamManager(provider);
  const cache = (fastify as any).cache as CacheManager;

  fastify.get('/', async (request: FastifyRequest, reply: FastifyReply) => {
    return reply.status(200).send({
      message: 'FlixHQ Movies Provider',
      endpoints: [
        'GET /:query - Search movies',
        'GET /info?id=:id - Get media info',
        'GET /watch?episodeId=:id&mediaId=:id - Get stream sources',
        'GET /servers?episodeId=:id&mediaId=:id - Get available servers',
        'GET /trending - Get trending movies',
        'GET /recent-movies - Get recent movies',
      ],
    });
  });

  fastify.get('/:query', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const { query } = request.params as { query: string };
      const validation = SearchQuerySchema.safeParse({
        query: decodeURIComponent(query),
        page: (request.query as any).page,
      });

      if (!validation.success) {
        return reply.status(400).send({
          error: 'Invalid request',
          details: validation.error.errors,
        });
      }

      const { query: searchQuery, page } = validation.data;
      const cacheKey = `movies:search:${searchQuery}:${page || 1}`;

      const results = await cache.fetch(cacheKey, () =>
        provider.search(searchQuery, page || 1),
      );

      return reply.status(200).send(results);
    } catch (error) {
      logger.error('Search error:', error);
      return reply.status(500).send({
        error: 'Search failed',
        message: (error as Error).message,
      });
    }
  });

  fastify.get('/info', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const validation = MediaInfoQuerySchema.safeParse(request.query);

      if (!validation.success) {
        return reply.status(400).send({
          error: 'Invalid request',
          details: validation.error.errors,
        });
      }

      const { id } = validation.data;
      const cacheKey = `movies:info:${id}`;

      const info = await cache.fetch(cacheKey, () => provider.fetchMediaInfo(id));

      return reply.status(200).send(info);
    } catch (error) {
      logger.error('Media info error:', error);
      return reply.status(500).send({
        error: 'Failed to fetch media info',
        message: (error as Error).message,
      });
    }
  });

  fastify.get('/watch', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const validation = EpisodeQuerySchema.safeParse(request.query);

      if (!validation.success) {
        return reply.status(400).send({
          error: 'Invalid request',
          details: validation.error.errors,
        });
      }

      const { episodeId, mediaId, servers } = validation.data;
      const cacheKey = `movies:watch:${episodeId}:${mediaId}:${servers?.join(',') || 'default'}`;

      const sources = await cache.fetch(cacheKey, () =>
        streamManager.fetchWithFallback({
          episodeId,
          mediaId,
          servers: servers as any,
          maxRetries: 3,
        }),
      );

      if (!sources) {
        return reply.status(404).send({
          error: 'No sources found',
          message: 'Could not find any playable sources for this episode',
        });
      }

      return reply.status(200).send({
        sources: sources.sources,
        availableServers: streamManager.getAvailableServers(),
      });
    } catch (error) {
      logger.error('Watch error:', error);
      return reply.status(500).send({
        error: 'Failed to fetch sources',
        message: (error as Error).message,
      });
    }
  });

  fastify.get('/servers', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const { episodeId, mediaId } = request.query as any;

      if (!episodeId || !mediaId) {
        return reply.status(400).send({
          error: 'Missing parameters',
          message: 'episodeId and mediaId are required',
        });
      }

      const cacheKey = `movies:servers:${episodeId}:${mediaId}`;

      const servers = await cache.fetch(cacheKey, () =>
        provider.fetchEpisodeServers(episodeId, mediaId),
      );

      return reply.status(200).send({
        servers: servers || [],
        availableServers: streamManager.getAvailableServers(),
      });
    } catch (error) {
      logger.error('Servers error:', error);
      return reply.status(500).send({
        error: 'Failed to fetch servers',
        message: (error as Error).message,
      });
    }
  });

  fastify.get('/trending', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const { type } = request.query as any;
      const cacheKey = `movies:trending:${type || 'all'}`;

      let results;
      if (type === 'tv') {
        results = await cache.fetch(cacheKey, () => provider.fetchTrendingTvShows());
      } else if (type === 'movies') {
        results = await cache.fetch(cacheKey, () => provider.fetchTrendingMovies());
      } else {
        const [movies, shows] = await Promise.all([
          cache.fetch('movies:trending:movies', () => provider.fetchTrendingMovies()),
          cache.fetch('movies:trending:tv', () => provider.fetchTrendingTvShows()),
        ]);
        results = { movies, shows };
      }

      return reply.status(200).send(results);
    } catch (error) {
      logger.error('Trending error:', error);
      return reply.status(500).send({
        error: 'Failed to fetch trending',
        message: (error as Error).message,
      });
    }
  });

  fastify.get('/recent-movies', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const cacheKey = 'movies:recent';
      const results = await cache.fetch(cacheKey, () => provider.fetchRecentMovies());

      return reply.status(200).send(results);
    } catch (error) {
      logger.error('Recent movies error:', error);
      return reply.status(500).send({
        error: 'Failed to fetch recent movies',
        message: (error as Error).message,
      });
    }
  });
}

export default moviesRoutes;
