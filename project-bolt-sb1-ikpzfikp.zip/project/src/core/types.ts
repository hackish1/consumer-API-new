export interface StreamSource {
  url: string;
  quality?: string;
  type?: string;
  headers?: Record<string, string>;
}

export interface StreamResult {
  sources: StreamSource[];
  subtitles?: SubtitleTrack[];
  download?: string;
}

export interface SubtitleTrack {
  url: string;
  lang: string;
}

export interface ServerOption {
  name: string;
  priority: number;
  enabled: boolean;
}

export interface SourceWithServer extends StreamSource {
  server: string;
}

export interface StreamCache {
  sources: SourceWithServer[];
  timestamp: number;
  ttl: number;
}

export type StreamingServers = 'vidcloud' | 'midstream' | 'filecdn' | 'streamhub' | 'mixdrop' | 'upcloud';

export const AVAILABLE_SERVERS: Record<StreamingServers, ServerOption> = {
  vidcloud: { name: 'VidCloud', priority: 1, enabled: true },
  midstream: { name: 'MidStream', priority: 2, enabled: true },
  filecdn: { name: 'FileCDN', priority: 3, enabled: true },
  streamhub: { name: 'StreamHub', priority: 4, enabled: true },
  mixdrop: { name: 'MixDrop', priority: 5, enabled: true },
  upcloud: { name: 'UpCloud', priority: 6, enabled: true },
};
