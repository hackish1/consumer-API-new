import { MOVIES } from '@consumet/extensions';
import { StreamingServers, StreamResult, SourceWithServer, AVAILABLE_SERVERS } from './types.js';
import { logger } from '../utils/logger.js';

type MovieProvider = InstanceType<typeof MOVIES.FlixHQ>;

interface FetchOptions {
  episodeId: string;
  mediaId: string;
  servers?: StreamingServers[];
  maxRetries?: number;
  timeout?: number;
}

export class StreamManager {
  private provider: MovieProvider;
  private serverQueue: StreamingServers[];
  private readonly MAX_RETRIES = 3;
  private readonly REQUEST_TIMEOUT = 10000;

  constructor(provider: MovieProvider) {
    this.provider = provider;
    this.serverQueue = this.getDefaultServerQueue();
  }

  private getDefaultServerQueue(): StreamingServers[] {
    return Object.entries(AVAILABLE_SERVERS)
      .filter(([, config]) => config.enabled)
      .sort(([, a], [, b]) => a.priority - b.priority)
      .map(([name]) => name as StreamingServers);
  }

  private getServerQueue(preferredServers?: StreamingServers[]): StreamingServers[] {
    if (!preferredServers || preferredServers.length === 0) {
      return this.serverQueue;
    }

    const enabled = preferredServers.filter((s) => AVAILABLE_SERVERS[s]?.enabled);
    if (enabled.length === 0) {
      logger.warn('No enabled servers in preferred list, using default queue');
      return this.serverQueue;
    }

    const remaining = this.serverQueue.filter((s) => !enabled.includes(s));
    return [...enabled, ...remaining];
  }

  async fetchWithFallback(options: FetchOptions): Promise<StreamResult | null> {
    const { episodeId, mediaId, servers, maxRetries = this.MAX_RETRIES } = options;
    const serverQueue = this.getServerQueue(servers);
    const allSources: SourceWithServer[] = [];
    let lastError: Error | null = null;

    for (const server of serverQueue) {
      for (let attempt = 1; attempt <= maxRetries; attempt++) {
        try {
          logger.info(
            `Fetching ${episodeId} from ${server} (attempt ${attempt}/${maxRetries})`,
          );

          const sources = await this.fetchFromServer(episodeId, mediaId, server);

          if (sources && sources.length > 0) {
            allSources.push(
              ...sources.map((source) => ({
                ...source,
                server,
              })),
            );

            logger.info(`Found ${sources.length} sources on ${server}`);

            if (allSources.length > 0) {
              return {
                sources: allSources,
                subtitles: undefined,
              };
            }
          }
        } catch (error) {
          lastError = error as Error;
          logger.error(
            `Failed to fetch from ${server} (attempt ${attempt}/${maxRetries}): ${lastError.message}`,
          );

          if (attempt < maxRetries) {
            await this.delay(1000 * attempt);
          }
        }
      }
    }

    if (allSources.length > 0) {
      return {
        sources: allSources,
        subtitles: undefined,
      };
    }

    logger.error(
      `Failed to fetch sources after trying all servers. Last error: ${lastError?.message}`,
    );
    return null;
  }

  private async fetchFromServer(
    episodeId: string,
    mediaId: string,
    server: StreamingServers,
  ): Promise<StreamResult['sources'] | null> {
    try {
      const result = await Promise.race([
        this.provider.fetchEpisodeSources(episodeId, mediaId, server as any),
        this.createTimeout(this.REQUEST_TIMEOUT),
      ]);

      if (!result) return null;

      const sources = result.sources || [];
      return sources.map((source: any) => ({
        url: source.url,
        quality: source.quality,
        type: source.type as string | undefined,
        headers: source.headers as Record<string, string> | undefined,
      }));
    } catch (error) {
      throw error;
    }
  }

  private createTimeout(ms: number): Promise<never> {
    return new Promise((_, reject) =>
      setTimeout(() => reject(new Error(`Request timeout after ${ms}ms`)), ms),
    );
  }

  private delay(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  setServerPriority(servers: StreamingServers[]): void {
    const validServers = servers.filter((s) => s in AVAILABLE_SERVERS);
    if (validServers.length > 0) {
      this.serverQueue = validServers;
      logger.info(`Server priority updated: ${validServers.join(', ')}`);
    }
  }

  getAvailableServers(): StreamingServers[] {
    return this.serverQueue;
  }
}
