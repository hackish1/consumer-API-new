# Consumet API v2 - Usage Examples

## Base URL
```
http://localhost:3000
```

## Movies API

### 1. Search Movies
```bash
# Search for "The Matrix"
curl "http://localhost:3000/movies/The%20Matrix"
```

Response:
```json
{
  "results": [
    {
      "id": "movie-123",
      "title": "The Matrix",
      "image": "https://...",
      "type": "movie"
    },
    {
      "id": "movie-456",
      "title": "The Matrix Reloaded",
      "image": "https://...",
      "type": "movie"
    }
  ]
}
```

### 2. Get Movie/Show Details
```bash
curl "http://localhost:3000/movies/info?id=movie-123"
```

Response:
```json
{
  "id": "movie-123",
  "title": "The Matrix",
  "description": "...",
  "image": "https://...",
  "episodes": [
    {
      "id": "episode-1",
      "number": 1,
      "title": "Episode 1",
      "season": 1
    }
  ]
}
```

### 3. Get Stream Sources with Auto-Fallback
The core feature - automatically tries multiple servers:

```bash
# Default server order (vidcloud → midstream → filecdn)
curl "http://localhost:3000/movies/watch?episodeId=episode-123&mediaId=movie-456"

# Custom server order
curl "http://localhost:3000/movies/watch?episodeId=episode-123&mediaId=movie-456&servers=midstream,vidcloud,filecdn"

# Single server (no fallback)
curl "http://localhost:3000/movies/watch?episodeId=episode-123&mediaId=movie-456&servers=vidcloud"
```

Response:
```json
{
  "sources": [
    {
      "url": "https://vidcloud.io/stream/abc123",
      "quality": "1080p",
      "type": "hls",
      "headers": {
        "Referer": "https://flixhq.to/"
      },
      "server": "vidcloud"
    },
    {
      "url": "https://midstream.io/stream/def456",
      "quality": "720p",
      "type": "mp4",
      "server": "midstream"
    }
  ],
  "availableServers": [
    "vidcloud",
    "midstream",
    "filecdn",
    "streamhub",
    "mixdrop",
    "upcloud"
  ]
}
```

### 4. Get Available Servers for Episode
```bash
curl "http://localhost:3000/movies/servers?episodeId=episode-123&mediaId=movie-456"
```

Response:
```json
{
  "servers": [
    {
      "name": "VidCloud",
      "url": "..."
    },
    {
      "name": "MidStream",
      "url": "..."
    }
  ],
  "availableServers": ["vidcloud", "midstream", "filecdn", "streamhub", "mixdrop", "upcloud"]
}
```

### 5. Get Trending Movies
```bash
# All trending (movies + TV shows)
curl "http://localhost:3000/movies/trending"

# Movies only
curl "http://localhost:3000/movies/trending?type=movies"

# TV shows only
curl "http://localhost:3000/movies/trending?type=tv"
```

Response:
```json
{
  "movies": [
    {
      "id": "movie-123",
      "title": "Top Movie",
      "image": "https://...",
      "releaseDate": "2026"
    }
  ],
  "shows": [
    {
      "id": "show-456",
      "title": "Top Show",
      "image": "https://...",
      "releaseDate": "2026"
    }
  ]
}
```

### 6. Get Recent Movies
```bash
curl "http://localhost:3000/movies/recent-movies"
```

---

## Anime API

### 1. Search Anime
```bash
curl "http://localhost:3000/anime/Naruto"
```

### 2. Get Anime Details
```bash
curl "http://localhost:3000/anime/info?id=anime-123"
```

### 3. Get Episode Sources
```bash
curl "http://localhost:3000/anime/watch?episodeId=episode-123"
```

### 4. Get Trending Anime
```bash
curl "http://localhost:3000/anime/trending"
```

### 5. Get Recent Episodes
```bash
curl "http://localhost:3000/anime/recent"
```

---

## Health Check API

### 1. Server Health
```bash
curl "http://localhost:3000/health"
```

Response:
```json
{
  "status": "healthy",
  "timestamp": "2026-03-12T17:30:45Z",
  "uptime": 3600
}
```

### 2. Readiness Check (Kubernetes)
```bash
curl "http://localhost:3000/health/ready"
```

Response:
```json
{
  "ready": true,
  "timestamp": "2026-03-12T17:30:45Z"
}
```

---

## Error Handling

All endpoints return consistent error responses:

### 400 - Bad Request
```json
{
  "error": "Invalid request",
  "details": [
    {
      "code": "invalid_type",
      "expected": "string",
      "received": "undefined",
      "path": ["episodeId"],
      "message": "episodeId is required"
    }
  ]
}
```

### 404 - Not Found
```json
{
  "error": "No sources found",
  "message": "Could not find any playable sources for this episode"
}
```

### 500 - Server Error
```json
{
  "error": "Failed to fetch sources",
  "message": "Detailed error message here"
}
```

---

## Advanced Usage

### Server Fallback Strategy

When multiple servers are specified, they're tried in order:

```javascript
// Request with custom server priority
GET /movies/watch?
  episodeId=episode-123&
  mediaId=movie-456&
  servers=filecdn,midstream,vidcloud
```

**Execution flow:**
1. Try FileCDN (attempt 1-3)
2. Try MidStream (attempt 1-3)
3. Try VidCloud (attempt 1-3)
4. Return all sources found

Each server gets up to 3 retry attempts before moving to the next server.

### Query Parameters

#### watch endpoint
| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| episodeId | string | Yes | - | Episode ID to fetch |
| mediaId | string | Yes | - | Media/Movie ID |
| server | string | No | - | Single server (deprecated, use servers) |
| servers | string | No | all | Comma-separated server names |

#### search endpoint
| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| query | string | Yes | - | Search query |
| page | number | No | 1 | Results page |

---

## Client-Side Integration

### JavaScript/TypeScript
```javascript
async function getMovieSources(episodeId, mediaId) {
  const response = await fetch(
    `http://localhost:3000/movies/watch?episodeId=${episodeId}&mediaId=${mediaId}`
  );

  if (!response.ok) {
    throw new Error(`Failed to fetch sources: ${response.statusText}`);
  }

  const data = await response.json();
  return data.sources; // Auto-selected from available servers
}
```

### Python
```python
import requests

def get_movie_sources(episode_id, media_id):
    url = f"http://localhost:3000/movies/watch"
    params = {
        "episodeId": episode_id,
        "mediaId": media_id,
        "servers": "vidcloud,midstream,filecdn"  # Priority order
    }

    response = requests.get(url, params=params)
    response.raise_for_status()

    return response.json()["sources"]
```

---

## Caching Behavior

Responses are cached based on endpoint:

| Endpoint | Cache Key | TTL |
|----------|-----------|-----|
| Search | `movies:search:{query}:{page}` | 1 hour |
| Info | `movies:info:{id}` | 1 hour |
| Watch | `movies:watch:{episodeId}:{mediaId}:{servers}` | 1 hour |
| Trending | `movies:trending:{type}` | 1 hour |

Override TTL in `.env`:
```env
CACHE_TTL=7200  # 2 hours
```

To disable caching:
```env
REDIS_HOST=  # Leave empty
```

---

## Rate Limiting

No built-in rate limiting yet. If deploying to production, add:

### Using Docker
```bash
docker run -d \
  -e PORT=3000 \
  -e REDIS_HOST=redis \
  -p 3000:3000 \
  consumet-api
```

### Using Vercel
```bash
vercel deploy
```

---

## Troubleshooting

### No sources found
```bash
# Check server status
curl "http://localhost:3000/movies/servers?episodeId=...&mediaId=..."

# Check with verbose logging
NODE_ENV=development LOG_LEVEL=debug npm run dev

# Try different servers
curl "...&servers=midstream,filecdn"
```

### Timeout errors
```bash
# Increase timeout in code, check logs
LOG_LEVEL=debug npm run dev
```

### Slow responses
```bash
# Enable Redis caching
REDIS_HOST=localhost npm start
```
