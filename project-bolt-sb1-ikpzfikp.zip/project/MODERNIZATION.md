# Consumet API v2 - Modernization Guide

## What's New

This is a complete modernization of the Consumet API with significant architectural and technical improvements.

### Key Improvements

#### 1. **Modern TypeScript Setup**
- Migrated from CommonJS to ES Modules
- Updated TypeScript target to ES2022
- Strict type checking enabled
- Better IDE support and type safety

#### 2. **Multi-Server Streaming with Auto-Fallback**
The most critical feature for your use case - servers like VidCloud, MidStream, and FileCDN now have intelligent fallback:

```typescript
// The StreamManager automatically tries servers in priority order
const streamManager = new StreamManager(provider);
const sources = await streamManager.fetchWithFallback({
  episodeId: 'episode-123',
  mediaId: 'media-456',
  servers: ['vidcloud', 'midstream', 'filecdn'],
  maxRetries: 3,
});
```

**How it works:**
1. Queries the primary server (VidCloud)
2. If no sources found, tries the next server (MidStream)
3. If that fails, tries FileCDN
4. Continues through all enabled servers with retry logic
5. Returns all sources found from all servers that worked
6. Automatically handles timeouts and connection errors

#### 3. **Request Validation**
All API endpoints now use Zod for strict input validation:

```typescript
const { episodeId, mediaId, servers } = EpisodeQuerySchema.parse(request.query);
```

Benefits:
- Type-safe request handling
- Clear error messages
- Prevention of invalid inputs

#### 4. **Structured Logging**
Replaced console.log with Pino logger:

```
[17:30:45] INFO: Fetching episode-123 from vidcloud (attempt 1/3)
[17:30:47] ERROR: Failed to fetch from vidcloud: timeout
[17:30:48] INFO: Found 5 sources on midstream
```

#### 5. **Improved Caching**
Better cache management with proper error handling:

```typescript
const sources = await cache.fetch(cacheKey, () =>
  streamManager.fetchWithFallback({ ... }),
  CACHE_TTL
);
```

#### 6. **Health Checks**
New `/health` and `/health/ready` endpoints for monitoring:

```bash
curl http://localhost:3000/health
{
  "status": "healthy",
  "timestamp": "2026-03-12T17:30:45Z",
  "uptime": 3600
}
```

#### 7. **Modern Dependencies**
- Fastify 4.28 (latest)
- TypeScript 5.4 (latest)
- Pino logging (production-grade)
- Zod validation
- Node 18+ (ES2022 support)

#### 8. **Better Error Handling**
All endpoints return consistent error responses:

```json
{
  "error": "No sources found",
  "message": "Could not find any playable sources for this episode"
}
```

---

## API Endpoints

### Movies
```
GET /movies/                          - Provider info
GET /movies/:query                    - Search movies
GET /movies/info?id=:id              - Get media details
GET /movies/watch?episodeId=:id&mediaId=:id&servers=vidcloud,midstream
                                     - Get stream sources (with server selection)
GET /movies/servers?episodeId=:id&mediaId=:id
                                     - List available servers
GET /movies/trending?type=movies     - Get trending
GET /movies/recent-movies            - Get recent
```

### Anime
```
GET /anime/                          - Provider info
GET /anime/:query                    - Search anime
GET /anime/info?id=:id              - Get anime details
GET /anime/watch?episodeId=:id      - Get episode sources
GET /anime/trending                 - Get trending
GET /anime/recent                   - Get recent episodes
```

### Health
```
GET /health/                         - Health status
GET /health/ready                    - Readiness probe
```

---

## Configuration

Update `.env` file:

```env
# Server
PORT=3000
NODE_ENV=development
LOG_LEVEL=debug
CACHE_TTL=3600

# Redis (Optional - for caching)
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_PASSWORD=

# TMDB (Optional - for metadata)
TMDB_KEY=
```

---

## Using Multi-Server Fallback

### Example: Get Movie Sources with Auto-Fallback

```bash
# Fetch from VidCloud first, fallback to MidStream, then FileCDN
curl "http://localhost:3000/movies/watch?episodeId=episode-123&mediaId=movie-456&servers=vidcloud,midstream,filecdn"

Response:
{
  "sources": [
    {
      "url": "https://vidcloud.co/...",
      "quality": "1080p",
      "server": "vidcloud"
    },
    {
      "url": "https://midstream.io/...",
      "quality": "720p",
      "server": "midstream"
    }
  ],
  "availableServers": ["vidcloud", "midstream", "filecdn", "streamhub", "mixdrop", "upcloud"]
}
```

### Priority Order
If no servers are specified, they're tried in this order by default:
1. VidCloud (Priority 1) - Most reliable
2. MidStream (Priority 2)
3. FileCDN (Priority 3)
4. StreamHub (Priority 4)
5. MixDrop (Priority 5)
6. UpCloud (Priority 6)

---

## Architecture

### Directory Structure
```
src/
├── main.ts                  - Server entry point
├── core/
│   ├── types.ts            - Type definitions
│   └── stream-manager.ts   - Multi-server streaming logic
├── routes/
│   ├── movies.ts           - Movies API
│   ├── anime.ts            - Anime API
│   └── health.ts           - Health checks
└── utils/
    ├── logger.ts           - Structured logging
    ├── cache-manager.ts    - Cache abstraction
    └── validation.ts       - Request validation schemas
```

### StreamManager
Handles the core logic for multi-server streaming:

```typescript
class StreamManager {
  async fetchWithFallback(options): Promise<StreamResult> {
    // 1. Gets server queue (in priority order)
    // 2. Tries each server in sequence
    // 3. Implements exponential backoff retry logic
    // 4. Aggregates sources from all working servers
    // 5. Returns combined results
  }
}
```

---

## Migration from v1

### Code Changes

**Old Way (v1):**
```typescript
const res = await flixhq.fetchEpisodeSources(episodeId, mediaId, 'vidcloud');
if (!res || !res.sources) {
  // Try another server manually...
}
```

**New Way (v2):**
```typescript
const result = await streamManager.fetchWithFallback({
  episodeId,
  mediaId,
  servers: ['vidcloud', 'midstream', 'filecdn'],
  maxRetries: 3,
});
```

---

## Performance Improvements

1. **Caching**: Responses cached for 1 hour (configurable)
2. **Parallel Requests**: Multiple providers queried simultaneously
3. **Timeout Handling**: 10-second timeout per server prevents hanging
4. **Smart Retry**: Exponential backoff prevents overwhelming servers
5. **Connection Pooling**: Redis connection reuse

---

## Development

```bash
# Install dependencies
npm install

# Development mode (with hot reload)
npm run dev

# Build
npm run build

# Production
npm start
```

---

## Monitoring & Debugging

View detailed logs:
```bash
NODE_ENV=development LOG_LEVEL=debug npm start
```

Example log output:
```
[17:30:45.123] INFO: Server listening on port 3000 in development mode
[17:30:46.456] INFO: Fetching episode-123 from vidcloud (attempt 1/3)
[17:30:47.789] ERROR: Failed to fetch from vidcloud: timeout
[17:30:48.012] INFO: Found 5 sources on midstream
[17:30:48.034] DEBUG: Cache set for key: movies:watch:episode-123:movie-456:vidcloud,midstream (TTL: 3600s)
```

---

## Troubleshooting

### No sources found on any server
1. Check server status at https://github.com/consumet/providers-status
2. Verify episode/media IDs are correct
3. Try increasing maxRetries in StreamManager
4. Check logs for specific server errors

### Slow responses
1. Enable Redis caching: `REDIS_HOST=localhost`
2. Increase CACHE_TTL for longer caching
3. Reduce number of retry attempts

### Memory issues
1. Reduce Redis maxmemory if needed
2. Clear old cache: `redis-cli FLUSHALL`

---

## What Was Removed

- Console.log statements (use Pino instead)
- Manual error handling in routes (now centralized)
- Duplicated code patterns (abstracted into utilities)
- Old Node 12 compatibility code

---

## Next Steps

To further improve:
1. Add database support (Supabase) for history tracking
2. Implement user authentication
3. Add rate limiting per IP
4. Create admin dashboard for monitoring
5. Add webhook support for provider updates
